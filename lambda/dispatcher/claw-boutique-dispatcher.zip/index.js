"use strict";
/**
 * Claw Boutique – Lambda Dispatcher
 * ----------------------------------
 * Consumes SNS messages and routes inbound events to Bedrock Agent (WhatsApp)
 * or the OpenClaw gateway (SES email, WhatsApp statuses).
 *
 * Supported event types
 * ─────────────────────
 * 1. AWS End User Messaging Social (WhatsApp) events
 *    Delivered by the service as SNS notifications.  The SNS `Message` field
 *    contains a JSON string whose top-level key is `whatsAppWebhookEntry`.
 *    That value is ITSELF another JSON-encoded string (a second serialisation
 *    layer performed by End User Messaging Social before publishing to SNS).
 *    We must therefore JSON.parse() twice:
 *
 *      SNS record
 *        └─ record.Sns.Message          ← first JSON.parse()  → outer envelope
 *             └─ .whatsAppWebhookEntry  ← second JSON.parse() → WhatsApp payload
 *                  ├─ .entry[].changes[].value.messages[]     (inbound messages)
 *                  └─ .entry[].changes[].value.statuses[]     (delivery receipts)
 *
 *    Routing:
 *      - Messages from SELLER_PHONE → forwarded to OpenClaw gateway (/webhook/seller)
 *        for processing by Claude (admin commands, restock, apology, etc.)
 *      - Messages from anyone else  → routed to Bedrock Agent (Nova Lite) for
 *        customer support, with reply sent back via EUMS.
 *    A fire-and-forget log POST is sent to OpenClaw for async record-keeping.
 *
 * 2. SES inbound email events (no-op)
 *    Email is no longer used as a 2-way channel. Seller commands flow through
 *    WhatsApp → OpenClaw.
 *
 * Environment variables
 * ─────────────────────
 *   OPENCLAW_GATEWAY_URL      – Base URL of the OpenClaw gateway
 *                               e.g. http://32.195.52.35:18789
 *   OPENCLAW_GATEWAY_TOKEN    – Bearer token sent in every request to OpenClaw
 *   BEDROCK_AGENT_ID          – Bedrock Agent ID
 *   BEDROCK_AGENT_ALIAS_ID    – Bedrock Agent Alias ID
 *   WHATSAPP_PHONE_NUMBER_ID  – EUMS origination phone number ID
 *   SELLER_PHONE              – E.164 phone number of the store owner; messages
 *                               from this number are routed to OpenClaw
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const axios_1 = __importDefault(require("axios"));
const client_bedrock_agent_runtime_1 = require("@aws-sdk/client-bedrock-agent-runtime");
const client_socialmessaging_1 = require("@aws-sdk/client-socialmessaging");
// ---------------------------------------------------------------------------
// Environment
// ---------------------------------------------------------------------------
const GATEWAY_URL = (process.env.OPENCLAW_GATEWAY_URL ?? "").replace(/\/$/, "");
const GATEWAY_TOKEN = process.env.OPENCLAW_GATEWAY_TOKEN ?? "";
const BEDROCK_AGENT_ID = process.env.BEDROCK_AGENT_ID ?? "";
const BEDROCK_AGENT_ALIAS_ID = process.env.BEDROCK_AGENT_ALIAS_ID ?? "";
const WHATSAPP_PHONE_NUMBER_ID = process.env.WHATSAPP_PHONE_NUMBER_ID ?? "";
const STORE_API_URL = (process.env.STORE_API_URL ?? "").replace(/\/$/, "");
const SELLER_PHONE = process.env.SELLER_PHONE ?? "";
if (!GATEWAY_URL) {
    console.warn("[dispatcher] OPENCLAW_GATEWAY_URL is not set – SES/status POSTs will fail");
}
if (!BEDROCK_AGENT_ID || !BEDROCK_AGENT_ALIAS_ID) {
    console.warn("[dispatcher] BEDROCK_AGENT_ID or BEDROCK_AGENT_ALIAS_ID is not set – WhatsApp messages will fail");
}
if (!WHATSAPP_PHONE_NUMBER_ID) {
    console.warn("[dispatcher] WHATSAPP_PHONE_NUMBER_ID is not set – WhatsApp replies will fail");
}
// ---------------------------------------------------------------------------
// AWS SDK clients
// ---------------------------------------------------------------------------
const bedrockAgentClient = new client_bedrock_agent_runtime_1.BedrockAgentRuntimeClient({});
const socialMessagingClient = new client_socialmessaging_1.SocialMessagingClient({});
function log(level, message, extra) {
    console[level === "ERROR" ? "error" : level === "WARN" ? "warn" : "log"](JSON.stringify({
        timestamp: new Date().toISOString(),
        level,
        message,
        ...extra,
    }));
}
// ---------------------------------------------------------------------------
// HTTP helper
// ---------------------------------------------------------------------------
async function postToGateway(path, body) {
    return postToUrl(`${GATEWAY_URL}${path}`, body);
}
async function postToUrl(url, body) {
    try {
        const response = await axios_1.default.post(url, body, {
            headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${GATEWAY_TOKEN}`,
            },
            timeout: 25000, // 25 s – allow time for agent processing
        });
        log("INFO", `POST succeeded`, {
            status: response.status,
            url,
        });
        return response.data;
    }
    catch (err) {
        const axiosErr = err;
        log("ERROR", `POST failed`, {
            url,
            status: axiosErr.response?.status,
            responseBody: axiosErr.response?.data,
            errorMessage: axiosErr.message,
        });
        throw err;
    }
}
/**
 * Invoke the Bedrock Agent with the customer's message text and return the
 * agent's reply by collecting all streaming response chunks.
 */
async function invokeBedrockAgent(senderPhone, messageText) {
    const command = new client_bedrock_agent_runtime_1.InvokeAgentCommand({
        agentId: BEDROCK_AGENT_ID,
        agentAliasId: BEDROCK_AGENT_ALIAS_ID,
        sessionId: senderPhone.replace(/\+/g, ""),
        inputText: messageText,
    });
    const response = await bedrockAgentClient.send(command);
    let replyText = "";
    if (response.completion) {
        for await (const event of response.completion) {
            if (event.chunk?.bytes) {
                replyText += new TextDecoder().decode(event.chunk.bytes);
            }
        }
    }
    return replyText;
}
/**
 * Submit a WhatsApp survey rating reply to the Store API review endpoint.
 * Returns the review response or null if the API call fails.
 */
async function submitWhatsAppReview(phone, rating) {
    if (!STORE_API_URL) {
        log("WARN", "STORE_API_URL not set, cannot submit WhatsApp review");
        return null;
    }
    try {
        const resp = await axios_1.default.post(`${STORE_API_URL}/api/reviews/from-whatsapp`, {
            phone,
            rating,
        }, { timeout: 10000 });
        return resp.data;
    }
    catch (err) {
        const axiosErr = err;
        log("WARN", "WhatsApp review submission failed", {
            phone,
            rating,
            status: axiosErr.response?.status,
            error: axiosErr.message,
        });
        return null;
    }
}
/**
 * Send a WhatsApp text reply via AWS End User Messaging Social (EUMS).
 */
async function sendWhatsAppReply(to, text) {
    const sendCmd = new client_socialmessaging_1.SendWhatsAppMessageCommand({
        originationPhoneNumberId: WHATSAPP_PHONE_NUMBER_ID,
        metaApiVersion: "v21.0",
        message: Buffer.from(JSON.stringify({
            messaging_product: "whatsapp",
            to,
            type: "text",
            text: { body: text },
        })),
    });
    await socialMessagingClient.send(sendCmd);
}
// ---------------------------------------------------------------------------
// SES email payload types (kept minimal - email is now notification-only)
// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
// Record processors
// ---------------------------------------------------------------------------
/**
 * Handles an End User Messaging Social (WhatsApp) SNS record.
 *
 * Double-parse explanation
 * ────────────────────────
 * AWS End User Messaging Social publishes events to SNS as follows:
 *
 *   SNS.Message = JSON.stringify({
 *     whatsAppWebhookEntry: JSON.stringify(actualWhatsAppPayload)
 *   })
 *
 * So when we receive the SNS notification:
 *   Step 1 – the Lambda runtime (or the SNS SDK) already parses the outer
 *             SNS wrapper, giving us `record.Sns.Message` as a raw string.
 *   Step 2 – we JSON.parse(record.Sns.Message) to get the outer envelope
 *             object, which has a `whatsAppWebhookEntry` string field.
 *   Step 3 – we JSON.parse(outerEnvelope.whatsAppWebhookEntry) to get the
 *             actual WhatsApp webhook payload (entries, changes, messages /
 *             statuses).
 *
 * If we only do one parse we are left holding a string, not the payload we
 * need – this is the most common pitfall when wiring up this integration.
 */
async function handleWhatsAppRecord(record) {
    const snsMessageRaw = record.Sns.Message;
    // ── Step 2: parse the outer EUMS envelope ────────────────────────────────
    let outerEnvelope;
    try {
        outerEnvelope = JSON.parse(snsMessageRaw);
    }
    catch (err) {
        log("ERROR", "Failed to parse EUMS outer SNS envelope", {
            messageId: record.Sns.MessageId,
            raw: snsMessageRaw.slice(0, 500),
        });
        return; // non-retryable parse error – skip this record
    }
    if (!outerEnvelope.whatsAppWebhookEntry) {
        log("WARN", "EUMS envelope missing whatsAppWebhookEntry – skipping", {
            messageId: record.Sns.MessageId,
            keys: Object.keys(outerEnvelope),
        });
        return;
    }
    // ── Step 3: parse the inner WhatsApp payload (the double-parse) ──────────
    let innerParsed;
    try {
        innerParsed = JSON.parse(outerEnvelope.whatsAppWebhookEntry);
    }
    catch (err) {
        log("ERROR", "Failed to parse inner whatsAppWebhookEntry JSON", {
            messageId: record.Sns.MessageId,
            raw: outerEnvelope.whatsAppWebhookEntry.slice(0, 500),
        });
        return;
    }
    // EUMS sends the inner payload in two possible formats:
    //   Format A (Meta Graph API style): {"object":"whatsapp_business_account","entry":[...]}
    //   Format B (EUMS style):           {"id":"...","changes":[...]}  — the entry itself
    // We normalise to Format A.
    let entries;
    if (Array.isArray(innerParsed.entry)) {
        entries = innerParsed.entry;
    }
    else if (Array.isArray(innerParsed.changes)) {
        // Format B: the inner payload IS a single entry
        entries = [innerParsed];
    }
    else {
        log("WARN", "Inner payload has neither entry[] nor changes[] – skipping", {
            messageId: record.Sns.MessageId,
            keys: Object.keys(innerParsed),
        });
        return;
    }
    log("INFO", "Processing WhatsApp webhook payload", {
        messageId: record.Sns.MessageId,
        entryCount: entries.length,
    });
    // Iterate over all entries and their changes
    for (const entry of entries) {
        for (const change of entry.changes ?? []) {
            const value = change.value;
            // ── Inbound messages (text, media, etc.) ────────────────────────────
            if (value.messages && value.messages.length > 0) {
                log("INFO", "Routing inbound WhatsApp messages", {
                    count: value.messages.length,
                    phoneNumberId: value.metadata?.phone_number_id,
                });
                // Route each message through Bedrock Agent and reply directly to customer
                for (const msg of value.messages) {
                    // WhatsApp 'from' field omits the '+' prefix; normalise to E.164
                    const rawFrom = msg.from ?? "";
                    const senderPhone = rawFrom.startsWith("+") ? rawFrom : `+${rawFrom}`;
                    const messageText = msg.text?.body ??
                        msg.interactive?.button_reply?.title ??
                        msg.interactive?.list_reply?.title ??
                        "";
                    if (!messageText) {
                        log("WARN", "Skipping non-text message", {
                            type: msg.type,
                            from: senderPhone,
                        });
                        continue;
                    }
                    // Seller commands go through WhatsApp self-chat → OpenClaw (linked device).
                    // All messages to the WABA number (including from the seller) are routed
                    // to the Bedrock Agent as normal customer interactions.
                    // Check if this is a survey rating reply (single digit 1-5)
                    const trimmed = messageText.trim();
                    if (/^[1-5]$/.test(trimmed)) {
                        const rating = parseInt(trimmed, 10);
                        log("INFO", "Detected survey rating reply", { from: senderPhone, rating });
                        const reviewResult = await submitWhatsAppReview(senderPhone, rating);
                        if (reviewResult) {
                            const name = reviewResult.customer_name || "there";
                            let replyMsg;
                            if (rating >= 4) {
                                replyMsg = `Thank you${name !== "there" ? ` ${name}` : ""}! We're glad you had a great experience. See you next time!`;
                            }
                            else if (rating === 3) {
                                replyMsg = `Thanks for your feedback${name !== "there" ? ` ${name}` : ""}. We'd love to do better next time! Let us know if there's anything specific we can improve.`;
                            }
                            else {
                                replyMsg = `We're sorry to hear that${name !== "there" ? ` ${name}` : ""}. Our store owner has been notified and will follow up with you personally. We appreciate your feedback.`;
                            }
                            await sendWhatsAppReply(senderPhone, replyMsg);
                            log("INFO", "Survey reply processed and response sent", { from: senderPhone, action: reviewResult.action });
                            continue;
                        }
                        // If review submission failed (e.g. no order found), fall through to Bedrock Agent
                        log("INFO", "Review submission failed, falling through to Bedrock Agent", { from: senderPhone });
                    }
                    log("INFO", "Invoking Bedrock Agent", {
                        from: senderPhone,
                        messageId: msg.id,
                    });
                    // Invoke Bedrock Agent and collect streaming reply
                    const replyText = await invokeBedrockAgent(senderPhone, messageText);
                    log("INFO", "Bedrock Agent reply received", {
                        from: senderPhone,
                        replyLength: replyText.length,
                    });
                    // Send the reply back to the customer via EUMS
                    await sendWhatsAppReply(senderPhone, replyText);
                    log("INFO", "WhatsApp reply sent", { to: senderPhone });
                    // Fire-and-forget log POST to OpenClaw for async record-keeping
                    if (GATEWAY_URL) {
                        postToGateway("/inbound/log", {
                            from: senderPhone,
                            text: messageText,
                            reply: replyText,
                            timestamp: msg.timestamp,
                        }).catch((err) => {
                            log("WARN", "OpenClaw log POST failed (non-fatal)", {
                                from: senderPhone,
                                error: err.message,
                            });
                        });
                    }
                }
            }
            // ── Delivery / read receipts (statuses) ─────────────────────────────
            if (value.statuses && value.statuses.length > 0) {
                log("INFO", "Routing WhatsApp delivery statuses", {
                    count: value.statuses.length,
                    phoneNumberId: value.metadata?.phone_number_id,
                });
                await postToGateway("/inbound/status", {
                    source: "whatsapp",
                    phoneNumberId: value.metadata?.phone_number_id,
                    displayPhoneNumber: value.metadata?.display_phone_number,
                    statuses: value.statuses,
                });
            }
            // Log if a change value carries neither messages nor statuses
            if (!value.messages?.length && !value.statuses?.length) {
                log("WARN", "WhatsApp change value has no messages or statuses", {
                    field: change.field,
                    valueKeys: Object.keys(value),
                    messageId: record.Sns.MessageId,
                });
            }
        }
    }
}
/**
 * Handles an SES inbound email SNS record.
 *
 * Email is no longer used as a 2-way channel. Seller notifications and
 * commands now flow through WhatsApp (seller messages → OpenClaw).
 * This handler only logs the event for visibility.
 */
async function handleSesEmailRecord(record) {
    log("INFO", "SES email received (no-op, seller channel is WhatsApp now)", {
        messageId: record.Sns.MessageId,
    });
}
// ---------------------------------------------------------------------------
// SNS source detection
// ---------------------------------------------------------------------------
/**
 * Determine the event type from the SNS record metadata.
 *
 * End User Messaging Social sets a specific MessageAttribute or uses a
 * recognisable TopicArn / Subject prefix.  We use a combination of:
 *   1. `record.Sns.Subject` – EUMS sets this to a well-known value
 *   2. `record.Sns.MessageAttributes` – EUMS injects `eventType`
 *   3. Falling back to payload inspection (presence of `whatsAppWebhookEntry`)
 */
function detectEventType(record) {
    const subject = record.Sns.Subject ?? "";
    const topicArn = record.Sns.TopicArn ?? "";
    const attrs = record.Sns.MessageAttributes ?? {};
    // End User Messaging Social publishes with this subject
    if (subject === "WhatsAppWebhookEvent") {
        return "whatsapp";
    }
    // Some deployments tag the topic ARN or inject a message attribute
    if (topicArn.toLowerCase().includes("whatsapp") ||
        topicArn.toLowerCase().includes("endusermessaging") ||
        attrs["eventType"]?.Value === "WhatsAppWebhookEvent") {
        return "whatsapp";
    }
    // SES notifications carry a `notificationType` field in the message body
    // and typically have a Subject like "Amazon SES Email Receipt Notification"
    if (subject.toLowerCase().includes("ses") || subject.toLowerCase().includes("email")) {
        return "ses";
    }
    // Payload-level heuristic – parse just enough to classify
    try {
        const parsed = JSON.parse(record.Sns.Message);
        if ("whatsAppWebhookEntry" in parsed)
            return "whatsapp";
        if ("notificationType" in parsed && "mail" in parsed)
            return "ses";
    }
    catch {
        // ignore parse errors here; they'll be handled in the specific processor
    }
    return "unknown";
}
// ---------------------------------------------------------------------------
// Main handler
// ---------------------------------------------------------------------------
const handler = async (event, _context, _callback) => {
    log("INFO", "Dispatcher invoked", {
        recordCount: event.Records.length,
    });
    // Process all records; errors in individual records are caught and logged
    // so they do not prevent other records in the same batch from being handled.
    const results = await Promise.allSettled(event.Records.map(async (record) => {
        const messageId = record.Sns.MessageId;
        const eventType = detectEventType(record);
        log("INFO", "Processing SNS record", {
            messageId,
            topicArn: record.Sns.TopicArn,
            subject: record.Sns.Subject,
            detectedType: eventType,
        });
        switch (eventType) {
            case "whatsapp":
                await handleWhatsAppRecord(record);
                break;
            case "ses":
                await handleSesEmailRecord(record);
                break;
            default:
                log("WARN", "Unknown event type – record skipped", {
                    messageId,
                    subject: record.Sns.Subject,
                    topicArn: record.Sns.TopicArn,
                });
        }
    }));
    // Surface any rejected promises as WARN (they were already ERROR-logged inside)
    let failureCount = 0;
    for (const result of results) {
        if (result.status === "rejected") {
            failureCount++;
            log("WARN", "Record processing promise rejected", {
                reason: String(result.reason),
            });
        }
    }
    log("INFO", "Dispatcher finished", {
        total: event.Records.length,
        succeeded: event.Records.length - failureCount,
        failed: failureCount,
    });
    // Do NOT throw – we don't want Lambda to retry the entire batch for a
    // partial failure.  Individual errors have been logged above.
};
exports.handler = handler;
// ---------------------------------------------------------------------------
// Example / test event
// ---------------------------------------------------------------------------
//
// Paste this into the Lambda console "Test" tab to simulate an End User
// Messaging Social WhatsApp inbound text message event.
//
// Structure reference:
//   https://docs.aws.amazon.com/social-messaging/latest/userguide/manage-event-subscriptions.html
//
// {
//   "Records": [
//     {
//       "EventVersion": "1.0",
//       "EventSubscriptionArn": "arn:aws:sns:us-east-1:123456789012:claw-boutique-whatsapp-topic:abc123",
//       "EventSource": "aws:sns",
//       "Sns": {
//         "SignatureVersion": "1",
//         "Timestamp": "2024-06-01T12:00:00.000Z",
//         "Signature": "EXAMPLE",
//         "SigningCertUrl": "https://sns.us-east-1.amazonaws.com/cert.pem",
//         "MessageId": "msg-uuid-0001",
//         "Message": "{\"whatsAppWebhookEntry\":\"{\\\"object\\\":\\\"whatsapp_business_account\\\",\\\"entry\\\":[{\\\"id\\\":\\\"WBA_ID_001\\\",\\\"changes\\\":[{\\\"value\\\":{\\\"messaging_product\\\":\\\"whatsapp\\\",\\\"metadata\\\":{\\\"display_phone_number\\\":\\\"+15550001234\\\",\\\"phone_number_id\\\":\\\"PN_ID_001\\\"},\\\"contacts\\\":[{\\\"profile\\\":{\\\"name\\\":\\\"Jane Doe\\\"},\\\"wa_id\\\":\\\"15559876543\\\"}],\\\"messages\\\":[{\\\"id\\\":\\\"wamid.ABC123\\\",\\\"from\\\":\\\"15559876543\\\",\\\"timestamp\\\":\\\"1717243200\\\",\\\"type\\\":\\\"text\\\",\\\"text\\\":{\\\"body\\\":\\\"Hello, I would like to book an appointment!\\\"}}]},\\\"field\\\":\\\"messages\\\"}]}]}\"}",
//         "Subject": "WhatsAppWebhookEvent",
//         "Type": "Notification",
//         "UnsubscribeUrl": "https://sns.us-east-1.amazonaws.com/?Action=Unsubscribe&SubscriptionArn=...",
//         "TopicArn": "arn:aws:sns:us-east-1:123456789012:claw-boutique-whatsapp-topic",
//         "MessageAttributes": {
//           "eventType": {
//             "Type": "String",
//             "Value": "WhatsAppWebhookEvent"
//           }
//         }
//       }
//     }
//   ]
// }
//
// Decoded inner payload (what's inside whatsAppWebhookEntry after JSON.parse):
// {
//   "object": "whatsapp_business_account",
//   "entry": [
//     {
//       "id": "WBA_ID_001",
//       "changes": [
//         {
//           "field": "messages",
//           "value": {
//             "messaging_product": "whatsapp",
//             "metadata": {
//               "display_phone_number": "+15550001234",
//               "phone_number_id": "PN_ID_001"
//             },
//             "contacts": [
//               { "profile": { "name": "Jane Doe" }, "wa_id": "15559876543" }
//             ],
//             "messages": [
//               {
//                 "id": "wamid.ABC123",
//                 "from": "15559876543",
//                 "timestamp": "1717243200",
//                 "type": "text",
//                 "text": { "body": "Hello, I would like to book an appointment!" }
//               }
//             ]
//           }
//         }
//       ]
//     }
//   ]
// }
//
// SES inbound email test event:
// {
//   "Records": [
//     {
//       "EventSource": "aws:sns",
//       "EventVersion": "1.0",
//       "EventSubscriptionArn": "arn:aws:sns:us-east-1:123456789012:claw-boutique-ses-topic:def456",
//       "Sns": {
//         "MessageId": "msg-uuid-0002",
//         "Subject": "Amazon SES Email Receipt Notification",
//         "TopicArn": "arn:aws:sns:us-east-1:123456789012:claw-boutique-ses-topic",
//         "Timestamp": "2024-06-01T12:05:00.000Z",
//         "Message": "{\"notificationType\":\"Received\",\"mail\":{\"source\":\"customer@example.com\",\"destination\":[\"hello@clawboutique.com\"],\"messageId\":\"ses-msg-001\",\"commonHeaders\":{\"from\":[\"Customer <customer@example.com>\"],\"to\":[\"hello@clawboutique.com\"],\"subject\":\"Appointment inquiry\",\"date\":\"Sat, 01 Jun 2024 12:05:00 +0000\"},\"headers\":[]},\"receipt\":{\"action\":{\"type\":\"S3\",\"bucketName\":\"claw-boutique-ses-inbox\",\"objectKey\":\"emails/ses-msg-001\"}},\"content\":null}",
//         "MessageAttributes": {},
//         "Type": "Notification",
//         "UnsubscribeUrl": "https://sns.us-east-1.amazonaws.com/?Action=Unsubscribe&...",
//         "SignatureVersion": "1",
//         "Signature": "EXAMPLE",
//         "SigningCertUrl": "https://sns.us-east-1.amazonaws.com/cert.pem"
//       }
//     }
//   ]
// }
//# sourceMappingURL=index.js.map